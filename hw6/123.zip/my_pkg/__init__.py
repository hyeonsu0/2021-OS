# __init__.py

from .aver_num import *
from .fibo_num import *
